#!/bin/sh
# sd-tool.sh — 板子 SD 卡工具：认卡 / 备份 / 还原 / 改 netboot IP
# 说明分层: `sd-tool.sh help`(简) · `help -v`(每命令详解+例子) · `help -vv`(原理&坑)
set -eu

# ---------- 全局: 抽出 -v 计数(可出现在任意位置), 其余参数原序保留 ----------
VERBOSE=0
n=$#; i=0
while [ "$i" -lt "$n" ]; do
    a="$1"; shift
    case "$a" in
        -v)        VERBOSE=$((VERBOSE+1)) ;;
        -vv)       VERBOSE=$((VERBOSE+2)) ;;
        -vvv)      VERBOSE=$((VERBOSE+3)) ;;
        --verbose) VERBOSE=$((VERBOSE+1)) ;;
        *) set -- "$@" "$a" ;;   # 非 -v 的推回队尾
    esac
    i=$((i+1))
done

die() { echo "$@" >&2; exit 1; }
# vlog LEVEL msg... : VERBOSE>=LEVEL 才印(到 stderr, 不污染数据输出)
vlog() { _l="$1"; shift; [ "$VERBOSE" -ge "$_l" ] && echo ">> $*" >&2 || true; }
trace_on() { [ "$VERBOSE" -ge 3 ] && set -x || true; }   # -vvv: 命令级 xtrace

# ---------- help(分级) ----------
show_help() {
    cat <<'EOF'
sd-tool.sh — 板子 SD 卡工具：认卡 / 备份 / 还原 / 改 netboot IP

用法:  sudo sh sd-tool.sh <命令> [参数]            (想看更细: 加 -v 或 -vv)

  info     看这张卡是什么、IP 现值          — 只读最安全, 先跑这个
  backup   把整张卡备份到一个目录            — 改卡前务必先备份
  restore  用备份覆盖一张卡                  — ⚠ 会清空目标卡
  set-ip   改卡上的 netboot IP

── 最常用流程: 给某张卡改 IP ───────────────
  1. sudo sh sd-tool.sh info   --dev /dev/sdb     # 认卡, 顺便拿到 env 档路径
  2. sudo sh sd-tool.sh backup --dev /dev/sdb     # 留底, 以防万一
  3. sudo sh sd-tool.sh set-ip --env <第1步给的env路径> --board <板子IP> --host <serverIP>
  4. 拔卡插回板子, 重开机生效
EOF
    if [ "$VERBOSE" -ge 1 ]; then cat <<'EOF'

═══ 各命令详解 (-v) ═══════════════════════════════════

【info】 探查一张卡（只读, 不改任何东西）
  sudo sh sd-tool.sh info [--dev /dev/sdb]
      --dev   指定卡; 不给则扫所有外接卡
  会印: 分区表 + 自动判卡型(orange / rock5b-netboot / 本地Armbian) + 卡上 IP 文本档现值

【backup】 备份一张卡（几分钟）
  sudo sh sd-tool.sh backup --dev /dev/sdb [--out <目录>] [--label <名>]
      --out     备份存哪   (默认 /soc_Alvin/sd-backup-<label>-<日期>/)
      --label   备份命名用 (默认取卡自己的 label)
  例:  sudo sh sd-tool.sh backup --dev /dev/sdb

【restore】 用备份覆盖一张卡   ⚠ 会清空目标卡
  sudo sh sd-tool.sh restore --backup <备份目录> --dev /dev/sdb [--yes]
      --backup  哪个备份目录 (backup 产出的那个)
      --yes     跳过确认     (默认要手打 YES)
  例:  sudo sh sd-tool.sh restore --backup /soc_Alvin/sd-backup-opi_root-0622-1603 --dev /dev/sdb

【set-ip】 改卡上的 netboot IP（改完插回板子重开机生效）
  sudo sh sd-tool.sh set-ip --env <env档路径> --board <板子IP> --host <NFS server IP> \
                            [--gateway <网关>] [--netmask <掩码>]
      --env       卡上的 env 档; 档名自动决定写哪种键:
                    .../boot/orangepiEnv.txt  → orange 板 (写 board_ip / server_ip)
                    .../rock5bEnv.txt         → rock5b 板 (写 ipaddr / serverip)
      --board     板子自己的 IP
      --host      NFS server 的 IP
      --gateway   不给 = 自动取 host(--host)网段的 .254;跨段/非标准拓扑请显式给
      --netmask   不给 = 255.255.255.0
  例:  sudo sh sd-tool.sh set-ip --env /media/$USER/opi_root/boot/orangepiEnv.txt \
                                 --board 172.17.236.10 --host 172.17.236.64

  小抄: 每个命令运行时加 -v 会逐步叙述在做什么, -vvv 还会开命令级 trace。
EOF
    fi
    if [ "$VERBOSE" -ge 2 ]; then cat <<'EOF'

═══ 原理 & 注意事项 (-vv) ═════════════════════════════

备份是怎么存的（不是整卡 dd, 那要 58G 太大）, 一个目录里 5 个档:
    bootloader.img          p1 之前的引导区(SPL/U-Boot), dd 出来
    partition-table.sfdisk  分区布局
    rootfs.tar.zst          p1 里的文件(只打包实际用量, 所以小)
    meta.env                元数据(分区起点 / fs 类型 / label / FS UUID …)
    SHA256SUMS              校验
还原顺序: 写分区表 → dd 引导区 → mkfs 重建 p1 → 解 tar → 复原 FS UUID
  (复原 UUID 是为了让卡上 fstab / armbianEnv 的 rootdev=UUID 还指得到)
  换卡大小不同也行(单分区卡): restore 把 p1 起点保持不变、自动填满目标卡 →
    备份 32G 还原到 64G = p1 撑满 64G(不浪费); 还原到 16G = 缩到 16G(只要数据塞得下,
    否则护栏拒绝)。label-id 保留故 PARTUUID 不变。多分区卡则用原表、目标须 ≥ 原卡。

set-ip 为什么按档名分键名:
    orange 的 boot.cmd 读 orangepiEnv.txt → 键叫 board_ip / server_ip …
    rock5b 的 U-Boot   读 rock5bEnv.txt   → 键叫 ipaddr / serverip …
       (rock5b 这套需先烧含 "load mmc 1:1 /rock5bEnv.txt; env import" 的 U-Boot)
    ⚠ rock5b 若不放 rock5bEnv.txt, 会走 U-Boot 编译进去的 fallback IP 236.210(会撞机),
       所以一定要用 set-ip 显式写一份。

注意:
    · 多数命令要 root(sudo)。
    · 读卡机偶尔显示 0B(接触不良) → backup/restore 前先用 info 确认显示真实容量。
    · restore 会清空整张目标卡, 护栏: 拒绝系统根盘 / 拒绝给分区(要整盘) / 先校验 SHA256 / 要打 YES。
EOF
    fi
}

# ---------- info ----------
cmd_info() {
    DEV=""
    while [ $# -gt 0 ]; do case "$1" in --dev) DEV="$2"; shift 2 ;; *) die "info: 未知参数 $1" ;; esac; done
    vlog 1 "只读探查; 不改任何东西"
    echo "== 块设备 =="
    if [ -n "$DEV" ]; then lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT "$DEV"
    else lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT | grep -vE 'loop|vda|vdb'; fi
    # 找挂载点判卡型 + 显示 netboot IP 文本档
    echo "== 卡型 + netboot IP 文本档 =="
    if [ -n "$DEV" ]; then
        _mps=$(lsblk -nro MOUNTPOINT "$DEV" 2>/dev/null | grep -v '^$')
    else  # 不带 --dev: 只看外接卡挂载点(/media …), 不碰系统挂载
        _mps=$(ls -d /media/*/* /media/* /mnt/* /run/media/*/* 2>/dev/null | sort -u)
    fi
    [ -n "$_mps" ] || { echo "  (没找到挂载的卡; 卡插好了吗? 或用 --dev 指定)"; return; }
    for mp in $_mps; do
        [ -d "$mp" ] || continue
        _kind="未知/其他"
        [ -d "$mp/rock5b" ] && ls "$mp/rock5b"/*/Image >/dev/null 2>&1 && _kind="rock5b netboot 卡 (p1 有 rock5b/<distro>/Image)"
        { [ -f "$mp/rock5bEnv.txt" ] || [ -f "$mp/uEnv.txt" ]; } && _kind="rock5b netboot 卡 (已含 env 文本档)"
        [ -f "$mp/boot/orangepiEnv.txt" ] && _kind="orange 卡 (orangepiEnv.txt)"
        [ -f "$mp/boot/armbianEnv.txt" ] && [ ! -d "$mp/rock5b" ] && _kind="本地启动 Armbian 卡 (armbianEnv.txt, 非 netboot)"
        echo "--- $mp  →  $_kind ---"
        for envf in "$mp/rock5bEnv.txt" "$mp/uEnv.txt" "$mp/boot/orangepiEnv.txt"; do
            [ -f "$envf" ] && { echo "  [$envf]"; grep -E '^(board_ip|server_ip|ipaddr|serverip|gateway|gatewayip|netmask|distro)=' "$envf" 2>/dev/null | sed 's/^/    /'; }
        done
        [ -d "$mp/rock5b" ] && { echo "  rock5b/ 下 distro:"; ls "$mp/rock5b" 2>/dev/null | sed 's/^/    /'; }
    done
}

# ---------- backup ----------
cmd_backup() {
    DEV="" OUT="" TAG=""
    while [ $# -gt 0 ]; do case "$1" in
        --dev) DEV="$2"; shift 2 ;; --out) OUT="$2"; shift 2 ;; --label) TAG="$2"; shift 2 ;;
        *) die "backup: 未知参数 $1" ;; esac; done
    [ -n "$DEV" ] || die "缺 --dev /dev/sdX"
    [ -b "$DEV" ] || die "$DEV 不是块设备(SD 插好了吗? 先 info 看看)"
    P1="${DEV}1"; [ -b "$P1" ] || die "找不到分区 $P1"
    trace_on
    BOOT_SECTORS="$(sfdisk -d "$DEV" 2>/dev/null | awk -F'start=[ ]*' '/start=/{split($2,a,","); print a[1]; exit}')"
    [ -n "$BOOT_SECTORS" ] || die "读不到分区表"
    LABEL="${TAG:-$(lsblk -no LABEL "$P1" 2>/dev/null | head -1)}"; LABEL="${LABEL:-sdcard}"
    FSTYPE="$(lsblk -no FSTYPE "$P1" 2>/dev/null | head -1)"
    FS_UUID="$(lsblk -no UUID "$P1" 2>/dev/null | head -1)"
    [ -n "$OUT" ] || OUT="/soc_Alvin/sd-backup-${LABEL}-$(date +%Y%m%d-%H%M)"
    mkdir -p "$OUT"; cd "$OUT"
    vlog 1 "p1 起始=${BOOT_SECTORS} sectors → 即 bootloader 区大小; label=$LABEL fs=$FSTYPE uuid=$FS_UUID"
    echo "=== 备份 $DEV → $OUT ==="
    vlog 1 "[1/4] dd 前 ${BOOT_SECTORS} sectors 为 bootloader.img"
    echo "[1/4] bootloader.img"; dd if="$DEV" of=bootloader.img bs=512 count="$BOOT_SECTORS" status=none
    vlog 1 "[2/4] sfdisk -d 导出分区表"
    echo "[2/4] partition-table.sfdisk"; sfdisk -d "$DEV" > partition-table.sfdisk
    vlog 1 "[3/4] mount ro 后 tar|zstd -T0 (只打包实际用量)"
    echo "[3/4] rootfs.tar.zst"
    _existing="$(findmnt -fno TARGET "$P1" 2>/dev/null | head -1)"
    if [ -n "$_existing" ]; then
        MNT="$_existing"; _selfmount=0
        echo "  (p1 已挂在 $MNT, 直接 tar 免重挂)"
    else
        MNT="$(mktemp -d)"; mount -o ro "$P1" "$MNT"; _selfmount=1
    fi
    ROOTFS_BYTES="$(du -sb "$MNT" | awk '{print $1}')"
    tar -C "$MNT" -cf - . | zstd -T0 -q -o rootfs.tar.zst
    [ "$_selfmount" = 1 ] && { umount "$MNT"; rmdir "$MNT"; }
    echo "[4/4] meta.env + SHA256SUMS"
    cat > meta.env <<EOF
BOOT_SECTORS=$BOOT_SECTORS
PTTYPE=dos
FSTYPE=$FSTYPE
FS_UUID=$FS_UUID
LABEL=$LABEL
ROOTFS_BYTES=$ROOTFS_BYTES
SRC_DEV=$DEV
SRC_SIZE=$(lsblk -dno SIZE "$DEV")
DATE="$(date '+%Y-%m-%d %H:%M')"
EOF
    sha256sum bootloader.img rootfs.tar.zst > SHA256SUMS
    sync; echo "=== 完成。$OUT ==="; ls -lh "$OUT"
}

# ---------- restore ----------
cmd_restore() {
    BK="" DEV="" ASSUME_YES=0
    while [ $# -gt 0 ]; do case "$1" in
        --backup) BK="$2"; shift 2 ;; --dev) DEV="$2"; shift 2 ;; --yes) ASSUME_YES=1; shift ;;
        *) die "restore: 未知参数 $1" ;; esac; done
    [ -n "$BK" ] && [ -d "$BK" ] || die "缺/错 --backup <目录>"
    [ -n "$DEV" ] && [ -b "$DEV" ] || die "缺/错 --dev /dev/sdX(块设备)"
    for f in bootloader.img partition-table.sfdisk meta.env; do [ -f "$BK/$f" ] || die "备份缺 $f"; done
    ROOTFS="$(ls "$BK"/rootfs.tar.* 2>/dev/null | head -1)"; [ -n "$ROOTFS" ] || die "备份缺 rootfs.tar.*"
    ROOTDISK="$(lsblk -no PKNAME "$(findmnt -no SOURCE / 2>/dev/null)" 2>/dev/null | head -1)"
    [ -n "$ROOTDISK" ] && [ "/dev/$ROOTDISK" = "$DEV" ] && die "拒绝: $DEV 是系统根盘!"
    case "$DEV" in *[0-9]) die "请给整盘 /dev/sdX 不是分区" ;; esac
    vlog 1 "校验备份 SHA256"
    ( cd "$BK" && sha256sum -c SHA256SUMS >/dev/null 2>&1 ) && echo "备份 SHA256 OK" || echo "⚠ SHA256 校验未过/缺"
    echo "=== 将还原到 ==="; lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT "$DEV"
    echo "备份来源:"; cat "$BK/meta.env"
    if [ "$ASSUME_YES" -ne 1 ]; then
        printf "\n这会**清空 %s** 并写入上面备份。打 YES 确认: " "$DEV"; read ans
        [ "$ans" = "YES" ] || die "已取消"
    fi
    trace_on
    # 先卸载目标盘上任何已挂载分区(否则 sfdisk 拒绝 repartition "disk in use", 常被 udisks 自动挂)
    for _m in $(lsblk -nro MOUNTPOINT "$DEV" 2>/dev/null | grep -v '^$'); do
        echo "  先卸载 $_m"; umount "$_m" 2>/dev/null || umount -l "$_m" 2>/dev/null || true
    done
    FS_UUID=""   # meta.env 旧版可能没有, 先给空值避免 set -u 报错
    # shellcheck disable=SC1090
    . "$BK/meta.env"; P1="${DEV}1"
    TGT_SECTORS=$(blockdev --getsz "$DEV" 2>/dev/null || echo 0)
    NPART=$(grep -c '^/dev/' "$BK/partition-table.sfdisk" 2>/dev/null || echo 1)
    NEED_B=$(( BOOT_SECTORS * 512 + ${ROOTFS_BYTES:-0} ))
    TGT_B=$(( TGT_SECTORS * 512 ))
    [ "$TGT_SECTORS" -gt 0 ] && [ "$TGT_B" -lt "$NEED_B" ] && \
        die "目标卡太小: $((TGT_B/1048576))MB < 需 $((NEED_B/1048576))MB(引导区+数据)。换大一点的卡。"
    # ⚠ 顺序关键: 先 dd bootloader, 再写分区表。
    # bootloader.img = 源卡前 BOOT_SECTORS(含 sector0/MBR=源卡旧分区表)。若后 dd 会
    # 把 resize 写好的分区表覆盖回旧大小 → 当下(分区表已在内核缓存)看不出, 一掉电
    # 重读 sector0 就退回旧大小。所以 sfdisk 必须最后写 sector0。
    vlog 1 "[1/5] dd bootloader.img 回 $DEV (含 SPL/U-Boot + 源旧MBR, 稍后被新分区表覆盖)"
    echo "[1/5] 写 bootloader"; dd if="$BK/bootloader.img" of="$DEV" bs=512 conv=fsync status=none
    vlog 1 "[2/5] 写分区表(在 dd 之后, 才能掉电保留; 按目标卡大小自动调 p1)"
    if [ "$NPART" = 1 ]; then
        LID=$(awk -F': *' '/label-id:/{print $2}' "$BK/partition-table.sfdisk" | tr -d ' ')
        PTYPE=$(sed -n 's/.*type=\([0-9A-Fa-f]*\).*/\1/p' "$BK/partition-table.sfdisk" | head -1)
        echo "[2/5] 写分区表: 单分区→p1 起点 $BOOT_SECTORS 不变, 自动填满目标卡($((TGT_B/1073741824))G); label-id 保留(PARTUUID 不变)"
        { echo "label: dos"; [ -n "$LID" ] && echo "label-id: $LID"; echo "start=$BOOT_SECTORS, type=${PTYPE:-83}"; } | sfdisk --wipe always "$DEV" || die "sfdisk 写分区表失败"
    else
        echo "[2/5] 写分区表: 多分区→用原表(目标卡须 ≥ 原卡, 不自动缩放)"
        sfdisk --wipe always "$DEV" < "$BK/partition-table.sfdisk" || die "sfdisk 写分区表失败"
    fi
    partprobe "$DEV" 2>/dev/null || true; sleep 1
    # 验证分区真写进去 + 单分区时确认填满目标卡
    [ -b "$P1" ] || die "$P1 没出现(分区表没生效?)。"
    if [ "$NPART" = 1 ] && [ "$TGT_SECTORS" -gt 0 ]; then
        ACT=$(blockdev --getsz "$P1" 2>/dev/null || echo 0); EXP=$(( TGT_SECTORS - BOOT_SECTORS ))
        PCT=$(( ACT * 100 / EXP ))
        [ "$PCT" -lt 90 ] && die "p1 没填满: 实际 $((ACT/2048))MB / 期望 ~$((EXP/2048))MB ($PCT%)。"
        echo "      → p1 实际 $((ACT/2048))MB (填满 ${PCT}%)"
    fi
    vlog 1 "[3/5] mkfs.${FSTYPE} 重建 $P1 (label=$LABEL)"
    echo "[3/5] mkfs.${FSTYPE} -L ${LABEL} $P1"; mkfs.${FSTYPE} -F -L "$LABEL" "$P1" >/dev/null 2>&1
    # [4/5] 复原 FS UUID (ext 系才能 tune2fs; 其它 fs 跳过)
    if [ -n "$FS_UUID" ]; then
        case "$FSTYPE" in
            ext2|ext3|ext4) echo "[4/5] 复原 FS UUID $FS_UUID"; tune2fs -U "$FS_UUID" "$P1" >/dev/null 2>&1 || echo "  (tune2fs 设 UUID 失败, 跳过)" ;;
            *) echo "[4/5] FS UUID 复原跳过 (fs=$FSTYPE 非 ext 系)" ;;
        esac
    else
        echo "[4/5] 备份无 FS_UUID 记录, 跳过 (旧版备份)"
    fi
    vlog 1 "[5/5] 解 $ROOTFS → $P1"
    echo "[5/5] 解 rootfs → $P1"
    MNT="$(mktemp -d)"; mount "$P1" "$MNT"
    case "$ROOTFS" in
        *.zst) zstd -dc "$ROOTFS" | tar -C "$MNT" -xf - ;;
        *.xz)  xz   -dc "$ROOTFS" | tar -C "$MNT" -xf - ;;
        *.gz)  gzip -dc "$ROOTFS" | tar -C "$MNT" -xf - ;;
        *)     tar -C "$MNT" -xf "$ROOTFS" ;;
    esac
    sync; umount "$MNT"; rmdir "$MNT"; echo "=== 还原完成。可拔卡。 ==="
}

# ---------- set-ip ----------
cmd_setip() {
    ENV="" BOARD_IP="" SERVER_IP="" GATEWAY="" NETMASK=""
    while [ $# -gt 0 ]; do case "$1" in
        --env) ENV="$2"; shift 2 ;; --board) BOARD_IP="$2"; shift 2 ;; --host) SERVER_IP="$2"; shift 2 ;;
        --gateway) GATEWAY="$2"; shift 2 ;; --netmask) NETMASK="$2"; shift 2 ;;
        *) die "set-ip: 未知参数 $1" ;; esac; done
    [ -n "$ENV" ]       || die "缺 --env <env 档路径> (orangepiEnv.txt 或 rock5bEnv.txt)"
    [ -n "$BOARD_IP" ]  || die "缺 --board <板子 IP>"
    [ -n "$SERVER_IP" ] || die "缺 --host <NFS server IP>"
    # 守卫检父目录(挡"SD 没挂"),允许新建档(rock5bEnv.txt 常是首次建)
    [ -d "$(dirname "$ENV")" ] || die "目录不存在 $(dirname "$ENV") — SD 挂载了吗?"
    # 防呆: 拒绝写到 host 根文件系统(SD 没挂时父目录可能恰好在 host 上, 会误写)
    _envsrc=$(findmnt -no SOURCE --target "$(dirname "$ENV")" 2>/dev/null)
    _rootsrc=$(findmnt -no SOURCE / 2>/dev/null)
    [ -n "$_envsrc" ] && [ "$_envsrc" = "$_rootsrc" ] && \
        die "拒绝: $ENV 落在 host 根盘($_rootsrc) — SD 没挂载? 别误写 host。先确认 SD 挂好。"
    # gateway 默认取 host(--host)网段的 .254;非标准拓扑请显式 --gateway
    [ -n "$GATEWAY" ] || GATEWAY="$(echo "$SERVER_IP" | awk -F. '{print $1"."$2"."$3".254"}')"
    [ -n "$NETMASK" ] || NETMASK="255.255.255.0"
    vlog 1 "gateway=$GATEWAY netmask=$NETMASK (缺省自动推)"
    trace_on
    if [ -f "$ENV" ]; then cp -a "$ENV" "${ENV}.bak-$(date +%Y%m%d-%H%M%S)"; echo "已备份: ${ENV}.bak-*"
    else echo "新建 $ENV(原不存在)"; fi
    # 键名按 env 档名自动选:
    #   rock5bEnv.txt / uEnv.txt (rock5b U-Boot) → 原生 ipaddr/serverip/gatewayip/netmask
    #   orangepiEnv.txt (orange)                 → board_ip/server_ip/gateway/netmask
    case "$(basename "$ENV")" in
        rock5bEnv.txt|uEnv.txt) K_BOARD=ipaddr;   K_HOST=serverip;  K_GW=gatewayip; K_MASK=netmask; _kind="rock5b (U-Boot 原生键)" ;;
        *)                      K_BOARD=board_ip; K_HOST=server_ip; K_GW=gateway;   K_MASK=netmask; _kind="orange orangepiEnv.txt" ;;
    esac
    vlog 1 "档名=$(basename "$ENV") → 键名风格: $_kind"
    set_kv() { _k="$1"; _val="$2"
        if [ -f "$ENV" ] && grep -qE "^${_k}=" "$ENV" 2>/dev/null; then sed -i "s#^${_k}=.*#${_k}=${_val}#" "$ENV"
        else printf '%s=%s\n' "$_k" "$_val" >> "$ENV"; fi; }
    set_kv "$K_BOARD" "$BOARD_IP"; set_kv "$K_HOST" "$SERVER_IP"
    set_kv "$K_GW" "$GATEWAY";     set_kv "$K_MASK" "$NETMASK"
    echo "=== 改后 $(basename "$ENV") ($_kind) ==="; cat "$ENV"; sync
    echo "=== 完成: board=$BOARD_IP host=$SERVER_IP gw=$GATEWAY mask=$NETMASK ==="
}

# ---------- dispatch ----------
if [ $# -lt 1 ]; then show_help; exit 2; fi
SUB="$1"; shift
case "$SUB" in
    info)    cmd_info    "$@" ;;
    backup)  cmd_backup  "$@" ;;
    restore) cmd_restore "$@" ;;
    set-ip)  cmd_setip   "$@" ;;
    help|-h|--help) show_help ;;
    *) die "未知子命令: $SUB (info|backup|restore|set-ip|help)" ;;
esac
