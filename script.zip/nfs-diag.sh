#!/usr/bin/env bash
# nfs-diag.sh —— 在 NFS server(234.53) 上跑,体检 orangepi netboot 的 server 端配置
# 用法: sudo ./nfs-diag.sh [板子IP] [rootfs路径]
#   默认 板子IP=172.17.235.15  rootfs=/soc_Alvin/nfs/rootfs/orangepi4pro/debian_12
# 产出: 终端打印 + 同时存到 ./nfs-diag-<时间>.log  → 把这个 log 贴回来
set -u

BOARD_IP="${1:-172.17.235.15}"
RFS="${2:-/soc_Alvin/nfs/rootfs/orangepi4pro/debian_12}"
LOG="./nfs-diag-$(date +%Y%m%d-%H%M%S).log"

# 所有输出同时进终端和 log
exec > >(tee "$LOG") 2>&1

sec(){ echo; echo "======== $* ========"; }
run(){ echo "\$ $*"; eval "$*" 2>&1; echo; }

echo "##### NFS server 体检 #####"
echo "时间   : $(date)"
echo "主机名 : $(hostname)"
echo "板子IP : $BOARD_IP"
echo "rootfs : $RFS"
echo "log    : $LOG"
[ "$(id -u)" -ne 0 ] && echo "⚠ 没用 root 跑,部分项(exportfs -v / 防火墙)可能不全 → 建议 sudo 重跑"

sec "1. 本机网卡 / IP (确认这台真的是 234.53)"
run "ip -4 addr show | grep -E 'inet |^[0-9]'"
echo ">> 期望看到 172.17.234.53"

sec "2. 板子 IP 是否可达 (反向 ping 板子;板子没开机会不通,正常)"
run "ping -c 2 -W 2 $BOARD_IP"

sec "3. NFS 服务状态"
run "systemctl is-active nfs-kernel-server 2>/dev/null || systemctl is-active nfs-server 2>/dev/null"
run "systemctl --no-pager status nfs-kernel-server 2>/dev/null | head -n 12"
run "ss -tlnp 2>/dev/null | grep -E ':2049|:111' || echo '(没看到 2049/111 监听 → NFS 没在跑?)'"

sec "4. /etc/exports 内容"
run "cat /etc/exports"
run "ls -1 /etc/exports.d/ 2>/dev/null && cat /etc/exports.d/*.exports 2>/dev/null"

sec "5. 当前生效的 export (exportfs -v)"
run "exportfs -v 2>&1"
echo ">> 必须有一行包含: $RFS  且子网涵盖板子 $BOARD_IP"

sec "6. 板子子网是否被 export 放行 (关键!跨网段坑)"
B3=$(echo "$BOARD_IP" | cut -d. -f1-3)        # 172.17.235
B2=$(echo "$BOARD_IP" | cut -d. -f1-2)        # 172.17
if exportfs -v 2>/dev/null | grep -q "$RFS"; then
  Eline=$(exportfs -v 2>/dev/null | grep "$RFS")
  echo "export 行: $Eline"
  if echo "$Eline" | grep -qE "${B3//./\\.}\.|${B2//./\\.}\.0\.0/16|\*|0\.0\.0\.0/0"; then
    echo "✓ 看起来放行了板子子网 ($B3.x 或 $B2.0.0/16)"
  else
    echo "✗ 没放行板子子网! export 只允许别的网段 → 板子会被拒(access denied)"
    echo "  修法: 把 /etc/exports 里该行子网改成 ${B2}.0.0/16 然后 sudo exportfs -ra"
  fi
else
  echo "✗ exportfs 里根本没有 $RFS → 没 export(restore 没成功 / 路径不对 / NFS 没起)"
fi

sec "7. rootfs 路径是否存在且有数据"
run "ls -ld $RFS"
run "ls -1 $RFS 2>/dev/null | head -n 30"
run "echo '顶层条目数:' \$(ls -1 $RFS 2>/dev/null | wc -l)"
run "du -sh $RFS 2>/dev/null"
echo ">> 期望: 看到 bin etc lib usr var ... 这种根文件系统目录;条目数十几个以上;du 几百MB~GB"

sec "8. 关键启动文件是否在 (kernel 从 SD 载,但 rootfs 要完整)"
for f in /etc/fstab /etc/os-release /sbin/init /bin/sh; do
  if [ -e "$RFS$f" ]; then echo "✓ $RFS$f"; else echo "✗ 缺 $RFS$f"; fi
done
run "cat $RFS/etc/os-release 2>/dev/null | grep -E 'PRETTY|VERSION'"

sec "9. showmount (客户端视角能看到啥)"
run "showmount -e localhost 2>&1"
echo ">> 要列出 $RFS"

sec "10. 防火墙 (可能挡 NFS)"
run "command -v ufw >/dev/null && ufw status 2>/dev/null || echo '(无 ufw)'"
run "iptables -L INPUT -n 2>/dev/null | head -n 15 || echo '(读不到 iptables,需 root)'"

sec "11. 本地自挂测试 (server 自己能不能挂自己,排除导出本身问题)"
TMPM=$(mktemp -d)
if mount -t nfs -o vers=3,tcp,nolock 127.0.0.1:"$RFS" "$TMPM" 2>/tmp/nfs-selfmount.err; then
  echo "✓ 本地自挂成功"
  ls -1 "$TMPM" | head -n 10
  umount "$TMPM" 2>/dev/null || umount -l "$TMPM" 2>/dev/null
else
  echo "✗ 本地自挂失败:"; cat /tmp/nfs-selfmount.err
fi
rmdir "$TMPM" 2>/dev/null

sec "完成"
echo "把整个 log 文件贴回来: $LOG"
