#!/bin/sh
# migrate-host.sh — host(NFS server) 整窝迁移: pack(旧机只读打包) / restore(新机还原)
# 配套 sd-tool.sh(改板子 SD 的 netboot IP)。本脚本只管 host 端。
#
# 场景: 旧 236 host 完全不动 → pack 出一个 bundle(只读) → 搬到新 235 host → restore(IP 改 235)。
#       (236 与 235 不互通, 所以 bundle 走 USB/移动盘搬。)
#
# 用法:
#   旧 236 host 上(只读, 不动 236):
#     sudo sh migrate-host.sh pack --out /media/$USER/usb/host-bundle.tar.zst [--level 10]
#
#   新 235 host 上(还原, 需 root):
#     sudo sh migrate-host.sh restore --bundle <bundle> --host-ip 172.17.235.64 \
#          [--target-root /soc_Alvin] [--opi 172.17.235.10] [--rock5b 172.17.235.210] [--dry-run]
#
# bundle 内容(全部数据+配置): nfs/rootfs/(rock5b+orangepi4pro 全 distro,~30G) +
#   etc/exports + final 脚本(sd-tool/migrate-host) + ssh(config 片段+key) + meta.txt
# 不含: tftp(已弃用,启动走 SD) / 板子 SD(那是卡上的事,用 sd-tool 改)
set -eu

# 全局: 抽出 -v 计数(可出现在任意位置), 其余参数原序保留
VERBOSE=0
n=$#; i=0
while [ "$i" -lt "$n" ]; do
    a="$1"; shift
    case "$a" in
        -v) VERBOSE=$((VERBOSE+1)) ;; -vv) VERBOSE=$((VERBOSE+2)) ;; -vvv) VERBOSE=$((VERBOSE+3)) ;;
        --verbose) VERBOSE=$((VERBOSE+1)) ;;
        *) set -- "$@" "$a" ;;
    esac
    i=$((i+1))
done

die() { echo "✗ $*" >&2; exit 1; }
log() { echo "▶ $*"; }

UHOME=$(eval echo "~${SUDO_USER:-$USER}")
NFS_ROOT=/soc_Alvin/nfs
FINAL_DIR=/soc_Alvin/tinatest_porting/final

# ---------- help(分级, 仿 sd-tool) ----------
show_help() {
    cat <<'EOF'
migrate-host.sh — host(NFS server) 整窝迁移到新网段

场景: 旧 host 完全不动 → pack 打包(只读) → 搬到新 host → restore(IP 自动改新段)
      新旧网段不互通时(如 236↔235), bundle 走 USB/移动盘搬。

用法:  sudo sh migrate-host.sh <pack|restore> [参数]        (想看更细: 加 -v 或 -vv)

  pack     在旧 host 打包(只读, 不动旧机)  → 一个 bundle 档
  restore  在新 host 还原 bundle + IP 自动改新段

── 完整迁移流程 ─────────────────────────────
  1.(旧机) sudo sh migrate-host.sh pack --out /media/$USER/usb/host-bundle.tar.zst
  2. bundle 拷到 USB, 搬到新机
  3.(新机) sudo sh migrate-host.sh restore --bundle <档> --host-ip <新host IP> \
                  --opi <orangepi新IP> --rock5b <rock5b新IP>
  4.(新机) 设本机网卡 IP 为新段 (netplan/nmcli)
  5. 每张板子 SD: sd-tool set-ip --host <新host IP> --board <板子新IP>
  6. 板子接到新网段重开机, 验证 NFS
EOF
    if [ "$VERBOSE" -ge 1 ]; then cat <<'EOF'

═══ 各命令详解 (-v) ═══════════════════════════════════

【pack】 旧 host 打包（只读, 完全不动旧机）
  sudo sh migrate-host.sh pack --out <bundle路径> (--opi | --rock5b | --all) [--level N]
      --out     bundle 存哪 (建议直接写 USB; 用 .tar.zst)
      --opi     只打包 orangepi4pro 的 rootfs(~7.7G)
      --rock5b  只打包 rock5b 的 rootfs(~22G)   (--opi --rock5b 可同时给)
      --all     打包全部 board 的 rootfs(含 odroid 等, ~30G)
      --level   zstd 压缩级 1快 ~ 19小 (默认 10)
  不管选哪个, etc/exports + final脚本 + ssh + meta.txt 都会一起打(小)。
  例:  sudo sh migrate-host.sh pack --out /media/$USER/usb/opi.tar.zst --opi
       sudo sh migrate-host.sh pack --out /media/$USER/usb/all.tar.zst --all
  注: 只打部分 board 时, restore 会自动把数据没含的 export 行注释掉(免 NFS 报错)。

【restore】 新 host 还原 + 改 IP
  sudo sh migrate-host.sh restore --bundle <档> --host-ip <新host IP> \
       [--target-root /soc_Alvin] [--opi <IP>] [--rock5b <IP>] [--dry-run]
      --bundle       pack 出的那个档
      --host-ip      新 host 的 IP (决定 exports 新子网 = 该 IP 的 /24)
      --target-root  数据还原到哪 (默认 /soc_Alvin)
      --opi/--rock5b 顺手把 ssh config 的板子 HostName 改成这些 (可省)
      --dry-run      只预览不动手 (免 root)
  例:  sudo sh migrate-host.sh restore --bundle host-bundle.tar.zst --host-ip 172.17.235.64 \
            --opi 172.17.235.10 --rock5b 172.17.235.210
EOF
    fi
    if [ "$VERBOSE" -ge 2 ]; then cat <<'EOF'

═══ 原理 & 注意事项 (-vv) ═════════════════════════════

bundle 里有什么:
    nfs/rootfs/   全 board 的 NFS 根(rock5b + orangepi 全 distro; 排除各 mnt 测试残留)
    etc/exports   原 NFS 导出表
    final/*.sh    sd-tool / migrate-host 工具(新机也就有了)
    ssh/          config 片段(Host opi4pro/rock5b) + id_ed25519 key
    meta.txt      原 host 的 子网/路径/板子IP (restore 据此改写)
  不含: tftp(已弃用, 启动走 SD) / 板子 SD(那是卡上的事, 用 sd-tool 改)

restore 自动改的(就是「只改 host IP」那套):
    /etc/exports 子网 旧→新(由 --host-ip 推 /24) + 路径 旧→--target-root

为什么旧机能不动:
    pack 全程只读(只 tar 读 rootfs / /etc/exports), 不碰旧机网卡/exports → 旧 host 照常服务。

新机还要手动(脚本不碰):
    · 新机网卡 IP 设成 --host-ip; 若新机也是 cloud-init 虚机, 记得关其网络配置(否则重开机被冲回 dhcp)。
    · 每张板子 SD 用 sd-tool set-ip --host <新host IP> --board <板子新IP>, 把 server_ip 指向新 host。
    · 板子接到新网段后重开机, showmount / 挂载验证。
EOF
    fi
}

# ───────────────── pack(旧机, 只读) ─────────────────
cmd_pack() {
    OUT=""; LEVEL=10; W_OPI=0; W_ROCK=0; W_ALL=0
    while [ $# -gt 0 ]; do case "$1" in
        --out) OUT="$2"; shift 2 ;; --level) LEVEL="$2"; shift 2 ;;
        --opi) W_OPI=1; shift ;; --rock5b) W_ROCK=1; shift ;; --all) W_ALL=1; shift ;;
        *) die "pack: 未知参数 $1" ;; esac; done
    [ "$(id -u)" = 0 ] || die "pack 需 root(读 rootfs 里 root-owned 档)"
    [ -n "$OUT" ] || die "缺 --out <bundle.tar.zst>(建议放 USB)"
    [ -d "$(dirname "$OUT")" ] && [ -w "$(dirname "$OUT")" ] || die "输出目录不存在或不可写: $(dirname "$OUT")"
    [ -d "$NFS_ROOT/rootfs" ] || die "找不到 $NFS_ROOT/rootfs"
    command -v zstd >/dev/null || die "缺 zstd"
    # 决定打包哪些 board 的 rootfs: --all=全部; 否则 --opi/--rock5b 选哪个就打哪个
    if [ "$W_ALL" = 1 ]; then
        RFS_ITEMS="rootfs"
    else
        RFS_ITEMS=""
        [ "$W_OPI" = 1 ]  && RFS_ITEMS="$RFS_ITEMS rootfs/orangepi4pro"
        [ "$W_ROCK" = 1 ] && RFS_ITEMS="$RFS_ITEMS rootfs/rock5b"
    fi
    [ -n "$RFS_ITEMS" ] || die "要指定打包范围: --opi(只orangepi) / --rock5b(只rock5b) / --all(全部)"
    for it in $RFS_ITEMS; do [ -d "$NFS_ROOT/$it" ] || die "范围不存在: $NFS_ROOT/$it"; done
    echo "  打包范围: $RFS_ITEMS"

    SUBNET=$(grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.0/[0-9]+' /etc/exports 2>/dev/null | sort -u | head -1)
    OPI=$(awk '/^Host opi4pro$/,/^$/{if($1=="HostName")print $2}' "$UHOME/.ssh/config" 2>/dev/null | head -1)
    R5B=$(awk '/^Host rock5b$/,/^$/{if($1=="HostName")print $2}' "$UHOME/.ssh/config" 2>/dev/null | head -1)

    TINY=$(mktemp -d); trap "rm -rf '$TINY'" EXIT
    cat > "$TINY/meta.txt" <<META
packed_at=$(date -Iseconds)
orig_host=$(hostname)
orig_subnet=${SUBNET:-unknown}
orig_nfs_root=$NFS_ROOT
orig_opi_ip=${OPI:-unknown}
orig_rock5b_ip=${R5B:-unknown}
packed_rootfs=$RFS_ITEMS
META
    awk '/^Host (opi4pro|rock5b)$/,/^$/' "$UHOME/.ssh/config" 2>/dev/null > "$TINY/config-snippet" || true

    _scope_sz=$(cd "$NFS_ROOT" && du -sch $RFS_ITEMS 2>/dev/null | tail -1 | cut -f1)
    log "打包(流式 tar|zstd -T0 -$LEVEL) → $OUT"
    log "内容: $RFS_ITEMS (~$_scope_sz) + etc/exports + final脚本 + ssh + meta"
    log "(排除各 rootfs 的 mnt 挂载残留; zstd -T0 多线程, ~$_scope_sz 数据视量约数分钟~20分钟)"
    # ssh key 可能不存在, 收集真正存在的项
    SSH_FILES=""
    [ -f "$UHOME/.ssh/id_ed25519" ]     && SSH_FILES="$SSH_FILES .ssh/id_ed25519"
    [ -f "$UHOME/.ssh/id_ed25519.pub" ] && SSH_FILES="$SSH_FILES .ssh/id_ed25519.pub"

    # shellcheck disable=SC2086
    tar --numeric-owner --acls --xattrs --xattrs-include='*' --sparse \
        --anchored --exclude='rootfs/*/*/mnt/*/*' --exclude='lost+found' \
        --transform 's|^meta.txt|bundle/meta.txt|' \
        --transform 's|^config-snippet|bundle/ssh/config-snippet|' \
        --transform 's|^rootfs|bundle/nfs/rootfs|' \
        --transform 's|^exports$|bundle/etc/exports|' \
        --transform 's|^\([^/]*\.sh\)$|bundle/final/\1|' \
        --transform 's|^.ssh/|bundle/ssh/|' \
        -cf - \
        -C "$TINY" meta.txt config-snippet \
        -C "$NFS_ROOT" $RFS_ITEMS \
        -C /etc exports \
        -C "$FINAL_DIR" $(cd "$FINAL_DIR" && ls *.sh) \
        ${SSH_FILES:+-C "$UHOME" $SSH_FILES} \
        | zstd -T0 -$LEVEL -q -o "$OUT"
    log "✓ 打包完成"; ls -lh "$OUT"
    echo "下一步: 把 $OUT 拷到 USB → 拿到新 235 host → migrate-host.sh restore"
}

# ───────────────── restore(新机) ─────────────────
cmd_restore() {
    BUNDLE=""; HOST_IP=""; TGT=/soc_Alvin; OPI=""; R5B=""; DRY=0
    while [ $# -gt 0 ]; do case "$1" in
        --bundle) BUNDLE="$2"; shift 2 ;; --host-ip) HOST_IP="$2"; shift 2 ;;
        --target-root) TGT="$2"; shift 2 ;; --opi) OPI="$2"; shift 2 ;;
        --rock5b) R5B="$2"; shift 2 ;; --dry-run) DRY=1; shift ;;
        *) die "restore: 未知参数 $1" ;; esac; done
    [ "$DRY" = 1 ] || [ "$(id -u)" = 0 ] || die "restore 需 root(预览可加 --dry-run 免 root)"
    [ "$DRY" = 1 ] || [ -f "$BUNDLE" ] || die "缺/错 --bundle <档>"
    [ -n "$HOST_IP" ] || die "缺 --host-ip <新 235 host IP>"
    NEW_SUBNET=$(echo "$HOST_IP" | awk -F. '{print $1"."$2"."$3".0/24"}')
    run() { if [ "$DRY" = 1 ]; then echo "  [dry] $*"; else eval "$@"; fi; }

    STAGE=/tmp/migrate-host-stage; log "解包 → $STAGE"
    run "rm -rf '$STAGE'; mkdir -p '$STAGE'"
    case "$BUNDLE" in
        *.zst) run "zstd -dc '$BUNDLE' | tar -C '$STAGE' -xf -" ;;
        *.gz)  run "tar -C '$STAGE' -xzf '$BUNDLE'" ;;
        *)     run "tar -C '$STAGE' -xf '$BUNDLE'" ;;
    esac
    B="$STAGE/bundle"
    if [ "$DRY" = 0 ]; then
        [ -d "$B" ] || die "bundle 结构异常"
        echo "── bundle meta ──"; sed 's/^/  /' "$B/meta.txt"
        ORIG_NFS=$(awk -F= '/^orig_nfs_root=/{print $2}' "$B/meta.txt")
        ORIG_SUBNET=$(awk -F= '/^orig_subnet=/{print $2}' "$B/meta.txt")
    else
        ORIG_NFS=/soc_Alvin/nfs; ORIG_SUBNET="172.17.236.0/24"
    fi

    log "[1/5] 还原 NFS rootfs → $TGT/nfs/rootfs/"
    run "mkdir -p '$TGT/nfs/rootfs'"
    run "cp -a '$B/nfs/rootfs/.' '$TGT/nfs/rootfs/'"

    log "[2/5] /etc/exports (路径 $ORIG_NFS→$TGT/nfs, 子网 $ORIG_SUBNET→$NEW_SUBNET)"
    run "[ -f /etc/exports ] && cp -a /etc/exports /etc/exports.bak-\$(date +%Y%m%d-%H%M%S) || true"
    run "sed -e 's#${ORIG_NFS}#${TGT}/nfs#g' -e 's#${ORIG_SUBNET}#${NEW_SUBNET}#g' '$B/etc/exports' > /etc/exports"
    # 部分打包(只 --opi/--rock5b)时, 把数据没还原过来的 export 行注释掉, 免 exportfs 报错
    if [ "$DRY" = 0 ]; then
        awk '/^[[:space:]]*#/||/^[[:space:]]*$/{print;next}
             {p=$1; if(system("[ -d \""p"\" ]")==0) print; else print "# [no-data] "$0}' \
            /etc/exports > /etc/exports.tmp.$$ && mv /etc/exports.tmp.$$ /etc/exports
        nc=$(grep -c '^# \[no-data\]' /etc/exports 2>/dev/null || echo 0)
        [ "$nc" -gt 0 ] && echo "  注释掉 $nc 条数据未含的 export(补数据后 sed -i 's/^# \[no-data\] //' + exportfs -ra 启用)"
    fi

    log "[3/5] final 脚本 → $TGT/tinatest_porting/final/"
    run "mkdir -p '$TGT/tinatest_porting/final'"
    run "cp -a '$B/final/.' '$TGT/tinatest_porting/final/' && chmod +x '$TGT/tinatest_porting/final/'*.sh"

    log "[4/5] ssh key + config 片段 → $UHOME/.ssh/ (HostName 改新 IP)"
    run "install -d -m700 '$UHOME/.ssh'"
    [ "$DRY" = 0 ] && [ -f "$B/ssh/id_ed25519" ] && run "install -m600 '$B/ssh/id_ed25519' '$UHOME/.ssh/' && install -m644 '$B/ssh/id_ed25519.pub' '$UHOME/.ssh/'"
    if [ "$DRY" = 0 ] && [ -f "$B/ssh/config-snippet" ]; then
        snip=$(sed -e "/^Host opi4pro\$/,/^\$/ s#HostName .*#HostName ${OPI:-keep}#" \
                   -e "/^Host rock5b\$/,/^\$/ s#HostName .*#HostName ${R5B:-keep}#" "$B/ssh/config-snippet")
        [ -n "$OPI" ] || snip=$(printf '%s' "$snip" | sed 's#HostName keep#&  # TODO 改 opi IP#')
        if ! grep -q '^Host opi4pro$' "$UHOME/.ssh/config" 2>/dev/null; then
            printf '\n%s\n' "$snip" >> "$UHOME/.ssh/config"; echo "  已加 ssh config 片段"
        else echo "  ssh config 已有 Host opi4pro, 跳过(手动 merge: $B/ssh/config-snippet)"; fi
    fi

    log "[5/5] 启 NFS"
    run "exportfs -ra 2>&1 | sed 's/^/  /' || true"
    run "systemctl restart nfs-kernel-server 2>/dev/null || echo '  ⚠ nfs-kernel-server 没装? apt install nfs-kernel-server'"
    [ "$DRY" = 0 ] && { echo "── showmount -e localhost ──"; showmount -e localhost 2>&1 | sed 's/^/  /'; }

    echo
    echo "═══ restore 完成($([ "$DRY" = 1 ] && echo DRY || echo 已执行)) ═══"
    echo "新 235 host 还要手动(脚本不碰):"
    echo "  □ 本机网卡 IP 设成 $HOST_IP(netplan/nmcli; 这台若也 cloud-init 记得关网络配置)"
    echo "  □ 每张板子 SD: sd-tool set-ip --host $HOST_IP --board <板子新IP>(server_ip 指向新 host)"
    echo "  □ 板子接到 235 网络后重开机, 看 NFS 起得来"
}

# ───────────────── dispatch ─────────────────
[ $# -ge 1 ] || { show_help; exit 2; }
SUB="$1"; shift
case "$SUB" in
    pack)    cmd_pack    "$@" ;;
    restore) cmd_restore "$@" ;;
    -h|--help|help) show_help ;;
    *) die "未知子命令: $SUB (pack|restore)" ;;
esac
